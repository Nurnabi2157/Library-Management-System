<?php
    session_start();
    require('./../database/connection.php');
    $id = $_POST['id'];
    $name = $_POST['name'];
    $dept = $_POST['department'];
    $batch = $_POST['batch'];
    $check = "SELECT `id` FROM `library` WHERE `id` = ? AND `name` = ? AND `department` = ? AND `batch` = ?;";
    $check_p = $conn->prepare($check);
    $check_p->execute([$id, $name, $dept, $batch]);
    if($check_p->rowCount() > 0){
        $_SESSION['data']['role'] = 'user';
        $_SESSION['data']['id'] = $id;
        header('location:./../dashboard.php');
        exit;
    }else{
        header('location:./../index.php');
        exit;
    }
?>