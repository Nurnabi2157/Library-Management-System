<?php
    require_once('./common/header.php');
?>
        <!-- Main COntent -->
        <main>

            <h2>Analytics</h2>
            <!-- Analytics -->
            <div class="analyse">
                <div class="sales">
                    <div class="status">
                        <div class="info">
                            <h3>Total Students</h3>
                            <h1>1365</h1>
                        </div>
                        <div class="progresss">
                            <svg>
                                <circle cx="38" cy="38" r="36"></circle>
                            </svg>
                            <div class="percentage">
                                <p>+81%</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="visits">
                    <div class="status">
                        <div class="info">
                            <h3>Site Visit</h3>
                            <h1>981</h1>
                        </div>
                        <div class="progresss">
                            <svg>
                                <circle cx="38" cy="38" r="36"></circle>
                            </svg>
                            <div class="percentage">
                                <p>80%</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="searches">
                    <div class="status">
                        <div class="info">
                            <h3>Searches</h3>
                            <h1>21375</h1>
                        </div>
                        <div class="progresss">
                            <svg>
                                <circle cx="38" cy="38" r="36"></circle>
                            </svg>
                            <div class="percentage">
                                <p>+91%</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End of Analyses -->
            <!--New User Section  -->
            <div class="new-users">
                <h2>New Users</h2>
                <div class="user-list">
                    <div class="user">
                        <img src="assets/images/prothomalo-bangla_2023-05_05c4d4e9-5bc1-4612-9a15-d9d1403b65ae_136.webp">
                        <h2>CSE Department</h2>
                        <p>54 Min Ago</p>
                    </div>
                    <div class="user">
                        <img src="assets/images/387813758_1745722895868197_8383514155997464408_n.jpg">
                        <h2>Studens of CSE</h2>
                        <p>3 Hours Ago</p>
                    </div>
                    <div class="user">
                        <img src="assets/images/sir 396867086_7307621469269098_820187202124159513_n.jpg">
                        <h2>Chairman Sir</h2>
                        <p>6 Hours Ago</p>
                    </div>
                    <div class="user">
                        <img src="assets/images/plus.png">
                        <h2>More</h2>
                        <p>New User</p>
                    </div>
                </div>
            </div>
            <!-- End of New User Section  -->
            <!-- Recent Order Table  -->
            <div class="recent-orders">
                <h2>Recent Orders</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Course Name</th>
                            <th>Course Number</th>
                            <th>Duration</th>
                            <th>Status</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
                <a href="#">Show All</a>
            </div>
            <!--End of Recent Order Table  -->
        </main>
<?php
    require_once('./common/footer.php');
?>            
