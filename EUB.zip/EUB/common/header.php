<?php
    session_start();
    if($_SESSION['data']['role'] != 'user' && $_SESSION['data']['email'] != ''){
        header('location: ./../index.php');
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <title>Responsive Dashboard Design #1 | EUB</title>
</head>
<body>
    <div class="container">
        <!-- Sidebar Selection -->
        <aside>
            <div class="toggle">
                <div class="logo">
                   <img src="assets/images/logo-EUB.png">
                   <h2>European <span class="success"> University</span></h2>
                </div>
                <div class="close" id="close-btn">
                    <span class="material-icons-sharp">
                        close
                    </span>
                </div>
            </div>
            <div class="sidebar">
                <a href="#">
                    <span class="material-icons-sharp">home</span>
                    <h3>Dashboard</h3>
                </a>
                <a href="#">
                    <span class="">ACADEMIC</span>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">grid_view</span>
                    <h3>Academic Calendar</h3>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">receipt_long</span>
                    <h3>ALL Project</h3>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">person</span>
                    <h3>Modules</h3>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">inventory</span>
                    <h3>Hardware Project</h3>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">inventory</span>
                    <h3>Software Project</h3>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">person</span>
                    <h3>Students</h3>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">person</span>
                    <h3>Teachers</h3>
                <a href="#">
                    <span class="material-icons-sharp">receipt_long</span>
                    <h3>History</h3>
                </a>
                <a href="#" class="active">
                    <span class="material-icons-sharp">insights</span>
                    <h3>Analytics</h3>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">inventory</span>
                    <h3>Lab Reports</h3>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">add</span>
                    <h3>New Login</h3>
                </a>
                <a href="#">
                    <span class="material-icons-sharp">logout</span>
                    <h3>Logout</h3>
                </a>
            </div>
        </aside>
        <!-- End of Sidebar Section -->