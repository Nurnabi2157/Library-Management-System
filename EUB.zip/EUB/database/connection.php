<?php
$servername = "localhost";
$usename = "root";
$password = "";
$db_name = "eub";
$conn = new PDO("mysql:host=$servername;dbname=$db_name", $usename,$password);
?>